package hotciv.variants;

import hotciv.framework.ActionStrategy;
import hotciv.framework.Game;
import hotciv.framework.Position;
import hotciv.framework.Unit;

public class AlphaActionStrategy implements ActionStrategy {

	@Override
	public void performAction(Game game, Position p) {

	}

}
