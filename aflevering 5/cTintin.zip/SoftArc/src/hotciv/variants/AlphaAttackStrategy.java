package hotciv.variants;

import hotciv.framework.AttackStrategy;
import hotciv.framework.Game;
import hotciv.framework.Position;

public class AlphaAttackStrategy implements AttackStrategy {

	@Override
	public boolean attack(Game game, Position attacker, Position defender) {
		// TODO Auto-generated method stub
		return true;
	}

}
