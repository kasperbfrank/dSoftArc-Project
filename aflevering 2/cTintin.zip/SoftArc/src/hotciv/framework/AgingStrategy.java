package hotciv.framework;

public interface AgingStrategy {
	public int doAging(int age);
}
