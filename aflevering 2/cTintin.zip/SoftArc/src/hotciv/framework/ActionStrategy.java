package hotciv.framework;

public interface ActionStrategy {
	public void performAction(Game game, Position p);
}
